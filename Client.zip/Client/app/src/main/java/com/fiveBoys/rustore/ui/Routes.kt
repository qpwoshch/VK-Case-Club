package com.fiveBoys.rustore.ui

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val FEED = "feed"
    const val CATEGORIES = "categories"
    const val DETAILS = "details"
}
